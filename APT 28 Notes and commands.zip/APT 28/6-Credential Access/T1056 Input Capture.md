

Keylogging T1056.001

keylogging with cs 

Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a keylogging tool or malware.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to known keylogging tools or suspicious executables with unusual command-line arguments.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes related to keyboard or input handling, such as Windows user interface components or accessibility features.