API token ,... SAAS

Windows Event Viewer:

- Event ID 4648 (Windows Server 2008 and later): A logon was attempted using explicit credentials, which could indicate an adversary attempting to use a stolen token for unauthorized access.
    

Sysmon:

- Event ID 10 - Process accessed: Monitor for processes accessing authentication or token-related processes or services, such as oauth2 or token management processes, especially those with unusual command-line arguments or suspicious behaviors.