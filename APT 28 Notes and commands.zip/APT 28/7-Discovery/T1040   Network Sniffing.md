

Windows Event Viewer:

- Event ID 7045 (Windows Server 2008 and later): A new network interface was created, which could indicate an adversary attempting to sniff network traffic using a new interface.
    
- Event ID 5152 (Windows Server 2008 and later): The Windows Filtering Platform has permitted a connection, which could indicate network traffic being captured or monitored by an unauthorized application.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections made by processes associated with network sniffing tools or unusual network activity, especially those connecting to internal systems or using non-standard network protocols.
    
- Event ID 5 - Process terminated: Monitor for termination of network monitoring or security tools, which could indicate an adversary trying to disable monitoring or hide their activity.
    
- Event ID 10 - Process accessed: Monitor for processes accessing network-related processes or services, such as network drivers or monitoring tools.