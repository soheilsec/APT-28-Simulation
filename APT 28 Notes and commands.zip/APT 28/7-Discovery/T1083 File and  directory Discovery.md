```cmd
forfiles /S /M *.pdf /C "cmd /c echo @path" 
forfiles /S /M *.xls* /C "cmd /c echo @path" 
forfiles /S /M *.doc* /C "cmd /c echo @path"
```



Windows Event Viewer:

- Event ID 4656 (Windows Server 2008 and later): A handle to an object was requested, which could indicate an adversary attempting to access or enumerate files and directories.
    
- Event ID 4663 (Windows Server 2008 and later): An attempt was made to access an object, which could indicate an adversary attempting to access or enumerate files and directories.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to file and directory discovery, such as dir, tree, or file management tools, especially those with unusual command-line arguments.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to file and directory discovery activities, especially those that are not part of standard system or application operations.
    
- Event ID 10 - Process accessed: Monitor for processes accessing file or directory-related processes or services, such as file management or command-line utilities, especially those with unusual command-line arguments or suspicious behaviors.