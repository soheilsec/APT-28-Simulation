


Windows Event Viewer:

- Event ID 20001 (Windows Vista and later): A device was connected to the system, which could indicate an adversary attempting to discover peripheral devices.
    
- Event ID 20003 (Windows Vista and later): A driver was installed on the system, which could indicate an adversary installing a malicious driver to interact with peripheral devices.
    

Sysmon:

- Event ID 6 - Driver loaded: Monitor for the loading of drivers related to peripheral devices, especially those that are not part of standard system operations or are associated with known adversary tools.
    
- Event ID 10 - Process accessed: Monitor for processes accessing device management processes or services, such as devcon, Device Manager, or the Windows Driver Kit, especially those with unusual command-line arguments or suspicious behaviors.