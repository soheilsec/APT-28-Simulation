


Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate an adversary attempting to discover running processes on the system.
    
- Event ID 4697 (Windows Server 2008 and later): A service was installed in the system, which could indicate an adversary installing a malicious service to monitor or interact with system processes.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to system monitoring, process enumeration, or known adversary tools, especially those with unusual command-line arguments.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes or system services, such as tasklist, taskkill, or WMI, especially those with unusual command-line arguments or suspicious behaviors.