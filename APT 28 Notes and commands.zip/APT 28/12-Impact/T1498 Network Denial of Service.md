

Windows Event Viewer:

- Event ID 4226 (Windows Server 2008 and later): A TCP/IP connection limit was reached, which could indicate an adversary attempting to exhaust network resources for a denial of service (DoS) attack.
    
- Event ID 2018 (Windows Server 2008 and later): A non-paged pool resource allocation error occurred, which could indicate an adversary attempting to consume system resources to disrupt network services.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for large volumes of network connections, unusual traffic patterns, or connections from suspicious IP addresses, which could indicate an adversary attempting to flood the network with traffic for a DoS attack.
    
- Event ID 13 - Network connection detected (with a specific IP address or subnet): Monitor for connections from IP addresses or subnets associated with known malicious actors or botnets, which could be indicative of a network DoS attack.