beef -> hook -> social engineering -> Access with cobalt payload

Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a browser or a malicious process after a drive-by compromise.
    
- Event ID 11 (Windows Server 2003): A new process has been created.
    
- Event ID 1003 (Internet Explorer): Internet Explorer has encountered an error, which could indicate a failed exploitation attempt.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to web browsers or malicious executables.
    
- Event ID 3 - Network connections: Monitor for network connections made by browser processes to suspicious domains.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to browser cache or suspicious files downloaded from compromised websites.