VPN , anydesk , vnc , ...

Windows Event Viewer:

- Event ID 5156 (Windows Server 2008 and later): The Windows Filtering Platform has permitted a connection. This event is useful for monitoring incoming and outgoing network connections.
    
- Event ID 4624 (Windows Server 2008 and later): An account was successfully logged on. This event can help identify successful remote logons, such as VPN connections or remote desktop sessions.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to remote services, such as VPN clients or remote access software.
    
- Event ID 3 - Network connections: Monitor for network connections made by processes associated with remote services.