Office

Link , Attachment





Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a malicious process from a spearphishing attachment or link.
    
- Event ID 1000 (Windows Server 2003): An application error has occurred, which could indicate an exploit attempt from a spearphishing attachment or link.
    
- Event IDs specific to email clients: Monitor for events related to email client processes (e.g., Outlook, Thunderbird) and suspicious attachments or URLs.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to email clients, web browsers, or malicious executables.
    
- Event ID 3 - Network connections: Monitor for network connections made by processes associated with email clients or web browsers, especially those connecting to suspicious domains or IP addresses.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to email attachments, browser cache, or suspicious files downloaded from phishing links.