

```powershell
$RemovableDrives=@()
$RemovableDrives = Get-WmiObject -Class Win32_LogicalDisk -filter "drivetype=2" | select-object -expandproperty DeviceID
ForEach ($Drive in $RemovableDrives)
{
write-host "Removable Drive Found:" $Drive
New-Item -Path $Drive/T1091Test1.txt -ItemType "file" -Force -Value "T1091 Test 1 has created this file to simulate malware spread to removable drives."
}
```
clean
```powershell
$RemovableDrives = Get-WmiObject -Class Win32_LogicalDisk -filter "drivetype=2" | select-object -expandproperty DeviceID
ForEach ($Drive in $RemovableDrives)
{
Remove-Item -Path $Drive\T1091Test1.txt -Force -ErrorAction Ignore
}
```


Removable Media Connection/Disconnection:

- Event ID 2003 (Windows Server 2003): Connection of a removable storage device, such as a USB drive.
    
- Event ID 2100 (Windows Server 2003): Disconnection of a removable storage device.
    

Autorun Activities:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate autorun execution.
    
- Event ID 4689 (Windows Server 2008 and later): A process has exited, which could indicate completion of autorun execution.
    

Process Execution:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate manual execution of malware from removable media.




	To monitor and detect T1091, consider the following Sysmon Event IDs:

1. Event ID 1 - Process creation: Monitor for the execution of processes related to removable media, such as explorer.exe or autorun.exe.
    
2. Event ID 13 - Registry value set: Monitor for changes to registry keys associated with Autorun features for removable media, such as HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer\NoDriveTypeAutoRun.
    
3. Event ID 14 - Registry value deleted: Monitor for the deletion of registry values related to Autorun features for removable media, which could indicate an attempt to enable Autorun for malicious purposes.