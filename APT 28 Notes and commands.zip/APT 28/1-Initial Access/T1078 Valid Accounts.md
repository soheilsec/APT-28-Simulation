
Access Broker {deepweb ,darkweb} credentials, token

Windows Event Viewer:

- Event ID 4624 (Windows Server 2008 and later): An account was successfully logged on, which could indicate the use of a valid account by an adversary.
    
- Event ID 4625 (Windows Server 2008 and later): An account failed to log on, which could indicate an attempted use of a valid account by an adversary.
    
- Event ID 4672 (Windows Server 2008 and later): Special privileges were assigned to a new logon, which could indicate the use of a privileged account.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to account discovery, credential dumping, or malicious executables.
    
- Event ID 3 - Network connections: Monitor for network connections made by processes associated with account discovery or credential dumping tools, especially those connecting to suspicious domains or IP addresses.
    
- Event ID 10 - Process accessed: Monitor for processes accessing lsass.exe or svchost.exe, which could indicate credential access or dumping attempts.