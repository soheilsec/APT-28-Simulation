buy or steal IT user Accounts

Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a trusted developer utility or a malicious process.
    
- Event ID 4688 with command-line arguments: Monitor for unusual command-line arguments used with developer utilities, such as powershell.exe, csc.exe, or [msbuild.exe](https://msbuild.exe).
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to trusted developer utilities, such as powershell.exe, csc.exe, msbuild.exe, or others specific to your environment.
    
- Event ID 3 - Network connections: Monitor for network connections made by trusted developer utility processes to suspicious domains or IP addresses.
    
- Event ID 8 - File creation: Monitor for the creation or modification of files related to developer utility directories or suspicious files used in conjunction with trusted developer utilities.