

Malicious File [T1204.001](https://attack.mitre.org/techniques/T1204/001/)


Malicious Link  [T1204.002](https://attack.mitre.org/techniques/T1204/002/)






Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a malicious executable file or process following a user clicking a malicious link.
    
- Event ID 1000 (Windows Server 2003): An application error has occurred, which could indicate an exploit attempt from a malicious file or link.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to malicious executables or web browser processes (chrome.exe, firefox.exe, iexplore.exe, etc.).
    
- Event ID 3 - Network connections: Monitor for network connections made by processes associated with web browsers or malicious executables, especially those connecting to suspicious domains or IP addresses.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to browser cache, malicious executable files (.exe, .dll, etc.), or suspicious files downloaded from malicious websites.