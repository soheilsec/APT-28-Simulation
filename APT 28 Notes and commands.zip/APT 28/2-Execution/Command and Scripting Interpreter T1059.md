
lnk
```cmd
.\gen-embed-zip.exe update.zip Report.lnk update.exe
```


Powershell T1059.001


Powershell cobaltstrike



Windows Command Shell T1059.003
cmd


Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of PowerShell (powershell.exe), Command Prompt (cmd.exe), or a malicious process.
    
- Event ID 4688 with command-line arguments: Monitor for unusual command-line arguments used with PowerShell and Command Prompt, such as obfuscated or encoded commands.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to PowerShell (powershell.exe) and Command Prompt (cmd.exe), or other script interpreters specific to your environment.
    
- Event ID 3 - Network connections: Monitor for network connections made by PowerShell or Command Prompt processes to suspicious domains or IP addresses.
    
- Event ID 8 - File creation: Monitor for the creation or modification of files related to script execution, such as PowerShell scripts (.ps1 files) or batch files (.bat or .cmd files).
