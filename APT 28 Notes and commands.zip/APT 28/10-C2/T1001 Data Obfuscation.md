

Junk Data T1001.001



Windows Event Viewer:

- Event ID 4656 (Windows Server 2008 and later): A handle to an object was requested, which could indicate an adversary attempting to access files for adding junk data.
    
- Event ID 4663 (Windows Server 2008 and later): An attempt was made to access an object, which could indicate an adversary attempting to access sensitive files for adding junk data.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to obfuscation tools, encryption software, or steganography utilities, especially those with unusual command-line arguments.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to adding junk data or obfuscating collected data, especially those that are not part of standard system or application operations.
    
- Event ID 10 - Process accessed: Monitor for processes accessing file-related processes or services, such as explorer.exe, cmd.exe, or PowerShell, especially those with unusual command-line arguments or suspicious behaviors.