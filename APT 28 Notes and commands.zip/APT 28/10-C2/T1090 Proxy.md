
External Proxy T1090.002



Windows Event Viewer:

- Event ID 5156 (Windows Server 2008 and later): The Windows Filtering Platform has permitted a connection, which could indicate an adversary making connections through an external proxy server for data exfiltration or C2 communication.
    
- Event ID 7045 (Windows Server 2008 and later): A new service was installed on the system, which could indicate an adversary installing a malicious service to facilitate external proxy usage.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections made to external proxy servers or services, especially those originating from unexpected or unauthorized sources, which could indicate an adversary attempting to conceal their activities or bypass network restrictions.
    
- Event ID 10 - Process accessed: Monitor for processes accessing proxy-related processes or services, such as proxy configuration tools or web browsers with proxy extensions, especially those with unusual command-line arguments or suspicious behaviors.



Multi-hop Proxy T1090.003

Adversaries may chain together multiple proxies to disguise the source of malicious traffic. Typically, a defender will be able to identify the last proxy traffic traversed before it enters their network; the defender may or may not be able to identify any previous proxies before the last-hop proxy. This technique makes identifying the original source of the malicious traffic even more difficult by requiring the defender to trace malicious traffic through several proxies to identify its source.

For example, adversaries may construct or use onion routing networks – such as the publicly available [Tor](https://attack.mitre.org/software/S0183) network – to transport encrypted C2 traffic through a compromised population, allowing communication with any device within the network.[[1]](https://en.wikipedia.org/wiki/Onion_routing)

In the case of network infrastructure, it is possible for an adversary to leverage multiple compromised devices to create a multi-hop proxy chain (i.e., [Network Devices](https://attack.mitre.org/techniques/T1584/008)). By leveraging [Patch System Image](https://attack.mitre.org/techniques/T1601/001) on routers, adversaries can add custom code to the affected network devices that will implement onion routing between those nodes. This method is dependent upon the [Network Boundary Bridging](https://attack.mitre.org/techniques/T1599) method allowing the adversaries to cross the protected network boundary of the Internet perimeter and into the organization’s Wide-Area Network (WAN). Protocols such as ICMP may be used as a transport.

Similarly, adversaries may abuse peer-to-peer (P2P) and blockchain-oriented infrastructure to implement routing between a decentralized network of peers.[[2]](https://unit42.paloaltonetworks.com/manageengine-godzilla-nglite-kdcsponge/)


Windows Event Viewer:

- Event ID 5156 (Windows Server 2008 and later): The Windows Filtering Platform has permitted a connection, which could indicate an adversary making connections through multiple proxy servers for data exfiltration or C2 communication.
    
- Event ID 7045 (Windows Server 2008 and later): A new service was installed on the system, which could indicate an adversary installing a malicious service to facilitate multi-hop proxy usage.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections made to multiple proxy servers or services, especially those originating from unexpected or unauthorized sources, which could indicate an adversary attempting to conceal their activities or bypass network restrictions using multi-hop proxy connections.
    
- Event ID 10 - Process accessed: Monitor for processes accessing proxy-related processes or services, such as proxy configuration tools or web browsers with proxy extensions, especially those with unusual command-line arguments or suspicious behaviors indicating the use of multiple proxies.

