
Mail Protocols T1071.003

Windows Event Viewer:

- Event ID 4648 (Windows Server 2008 and later): A logon attempt was made using explicit credentials, which could indicate an adversary using captured credentials obtained through email protocols.
    
- Event ID 7045 (Windows Server 2008 and later): A new service was installed on the system, which could indicate an adversary installing a malicious service to facilitate email protocol exploitation.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections made to email servers or services using SMTP, POP3, or IMAP protocols, especially those originating from unexpected or unauthorized sources, which could indicate an adversary attempting to communicate with C2 servers or exfiltrate data.
    
- Event ID 10 - Process accessed: Monitor for processes accessing email client processes or services, such as Outlook, Thunderbird, or webmail clients, especially those with unusual command-line arguments or suspicious behaviors.


Web Protocols T1071.001
Adversaries may communicate using application layer protocols associated with web traffic to avoid detection/network filtering by blending in with existing traffic. Commands to the remote system, and often the results of those commands, will be embedded within the protocol traffic between the client and server.

Protocols such as HTTP/S[[1]](http://cdn0.vox-cdn.com/assets/4589853/crowdstrike-intelligence-report-putter-panda.original.pdf) and WebSocket[[2]](https://securityintelligence.com/posts/brazking-android-malware-upgraded-targeting-brazilian-banks/) that carry web traffic may be very common in environments. HTTP/S packets have many fields and headers in which data can be concealed. An adversary may abuse these protocols to communicate with systems under their control within a victim network while also mimicking normal, expected traffic.

Windows Event Viewer:

- Event ID 5156 (Windows Server 2008 and later): The Windows Filtering Platform has permitted a connection, which could indicate an adversary making HTTP(S) connections for data exfiltration.
    
- Event ID 7045 (Windows Server 2008 and later): A new service was installed on the system, which could indicate an adversary installing a malicious service to facilitate web protocol exploitation.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections made to web servers or services using HTTP(S), FTP, or DNS protocols, especially those originating from unexpected or unauthorized sources, which could indicate an adversary attempting to communicate with C2 servers or exfiltrate data.
    
- Event ID 10 - Process accessed: Monitor for processes accessing web-related processes or services, such as web browsers, web server processes (e.g., httpd, nginx, IIS), or DNS services, especially those with unusual command-line arguments or suspicious behaviors.

