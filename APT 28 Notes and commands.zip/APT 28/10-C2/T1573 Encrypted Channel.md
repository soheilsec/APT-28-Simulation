
Symmetric Cryptography T1573.001
Common symmetric encryption algorithms include AES, DES, 3DES, Blowfish, and RC4.


Windows Event Viewer:

- Event ID 4663 (Windows Server 2008 and later): An attempt was made to access an object, which could indicate an adversary attempting to access encrypted files or data.
    

Sysmon:

- Event ID 10 - Process accessed: Monitor for processes accessing cryptographic libraries or APIs, such as Microsoft's CryptoAPI or OpenSSL, especially those with unusual command-line arguments or suspicious behaviors, which could indicate an adversary attempting to use symmetric encryption algorithms.
    
- Event ID 11 - File creation: Monitor for file creations with known extensions associated with encrypted files (e.g., .enc, .locky, .crypto), especially those created by processes with unusual command-line arguments or suspicious behaviors.