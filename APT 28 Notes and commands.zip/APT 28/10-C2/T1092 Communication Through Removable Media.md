
Windows Event Viewer:

- Event ID 2003 (Windows Server 2008 and later): The operating system successfully loaded and started a device driver, which could indicate the use of a removable media device.
    
- Event ID 4663 (Windows Server 2008 and later): An attempt was made to access an object, which could indicate an adversary attempting to access sensitive files stored on removable media.
    

Sysmon:

- Event ID 13 - Removable media detection: Monitor for connections or disconnections of removable media devices, such as USB drives or SD cards, especially those originating from unexpected or unauthorized sources, which could indicate an adversary attempting to transfer data using removable media.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions on removable media devices, especially those that are not part of standard system or application operations.
    
- Event ID 10 - Process accessed: Monitor for processes accessing removable media-related processes or services, such as explorer.exe, diskpart.exe, or diskmgmt.msc, especially those with unusual command-line arguments or suspicious behaviors.