

Bidirectional communication T1102.002



Windows Event Viewer:

- Event ID 5152 (Windows Server 2008 and later): The Windows Filtering Platform blocked a packet, which could indicate an adversary attempting to establish bidirectional communication channels for C2 communication.
    
- Event ID 5156 (Windows Server 2008 and later): The Windows Filtering Platform has permitted a connection, which could indicate an adversary successfully establishing a bidirectional communication channel.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections made to external servers or services, especially those originating from unexpected or unauthorized sources, which could indicate an adversary attempting to establish bidirectional communication channels for C2 communication.
    
- Event ID 10 - Process accessed: Monitor for processes accessing network-related processes or services, such as net.exe, netstat.exe, or network-related APIs, especially those with unusual command-line arguments or suspicious behaviors.