
```cmd
HKCU\Environment\UserInitMprLogonScript
```


Logon Script (Windows) T1037.001

```cmd
REG.exe ADD HKCU\Environment /v UserInitMprLogonScript /t REG_SZ /d "payload.bat" /f
```

delete 
```cmd
REG.exe DELETE HKCU\Environment /v UserInitMprLogonScript /f >nul 2>&1
```


Startup Items T1037.005

``` cmd
SharPersist -t startupfolder -c "C:\Windows\System32\cmd.exe" -a "/c calc.exe" -f "Some File" -m add
```

===remove===
```cmd
SharPersist -t startupfolder -f "Some File" -m remove
```

Registry

``` cmd
SharPersist -t reg -c "C:\Windows\System32\cmd.exe" -a "/c calc.exe" -k "hkcurun" -v "Test Stuff" -m add
```


```cmd
SharPersist -t reg -c "C:\Windows\System32\cmd.exe" -a "/c calc.exe" -k "hkcurun" -v "Test Stuff" -m add -o env
```

```cmd
SharPersist -t reg -c "C:\Windows\System32\cmd.exe" -a "/c calc.exe" -k "logonscript" -m add
```


===remove====
```
SharPersist -t reg -k "hkcurun" -v "Test Stuff" -m remove
```

```cmd
SharPersist -t reg -k "hkcurun" -v "Test Stuff" -m remove -o env

```


```cmd
SharPersist -t reg -k "logonscript" -m remove
```



Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a process attempting to access credential files or stealing credentials from web browsers.

- Event ID 4656 (Windows Server 2008 and later): A handle to an object was requested, which could indicate the opening or manipulation of credential files, such as configuration or registry files.


Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to web browsers, credential dumping tools, or malicious executables.

- Event ID 3 - Network connections: Monitor for network connections made by processes associated with web browsers or credential dumping tools, especially those connecting to suspicious domains or IP addresses.

- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to credential files, browser cache, or suspicious files downloaded from malicious websites.

- Event ID 9 - Registry operations: Monitor for modifications to registry keys associated with web credentials or autologon settings.

