VNC, teamviewer, anydesk, VPN


Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a process related to external remote services, such as Remote Desktop, SSH, or VPN clients.

- Event ID 5152 (Windows Server 2012 and later): The Windows Filtering Platform blocked a packet, which could indicate a blocked connection attempt to an external remote service.


Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to remote access tools, such as mstsc.exe, plink.exe, putty.exe, or VPN clients.

- Event ID 3 - Network connections: Monitor for network connections made by processes associated with remote access tools, especially those connecting to suspicious domains or IP addresses.
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to remote access tools or suspicious files downloaded from external sources.