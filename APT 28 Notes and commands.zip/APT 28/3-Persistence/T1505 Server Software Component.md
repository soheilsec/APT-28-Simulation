

Web Shell T1505.003




Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a web server process or a suspicious process related to web shells.
    
- Event ID 5145 (Windows Server 2008 and later): A network share object was checked to see whether a client can be granted desired access, which could indicate an attempt to access or modify web server files.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to web servers (w3wp.exe, httpd.exe, nginx.exe, etc.) or suspicious processes associated with web shells.
    
- Event ID 3 - Network connections: Monitor for network connections made by processes associated with web servers, especially those connecting to suspicious domains or IP addresses.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to web server directories or suspicious files associated with web shells.