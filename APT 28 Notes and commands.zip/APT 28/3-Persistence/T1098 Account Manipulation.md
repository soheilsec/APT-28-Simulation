

Additional Email Delegate Permissions [T1098.002](https://attack.mitre.org/techniques/T1098/002/)
 `Add-MailboxPermission` 
 BEC (Business Email Compromise) 

Windows Event Viewer:

- Event IDs specific to Exchange Server: Monitor for events related to mailbox access, delegate permissions, or changes in mailbox audit logs. Some relevant events may include Event ID 1013 (Mailbox Auditing), Event ID 700 (Access Control List), and Event ID 3 (Success Audit).

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to email clients, Exchange Server management tools, or malicious executables.

- Event ID 3 - Network connections: Monitor for network connections made by processes associated with email clients or Exchange Server management tools, especially those connecting to suspicious domains or IP addresses.

- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to email clients, Exchange Server, or suspicious files downloaded from malicious emails.

