
Bootkit T1542.003
A bootkit is a malware variant that modifies the boot sectors of a hard drive, including the Master Boot Record (MBR) and Volume Boot Record (VBR)

Windows Event Viewer:

- Event ID 7045 (Windows Server 2008 and later): A new service was installed in the system, which could indicate the installation of a malicious bootkit.
    
- Event ID 6006 (Windows Server 2008 and later): The event log service was stopped, which could indicate a system shutdown or restart related to a bootkit installation.
    

Sysmon:

- Event ID 16 - Service configuration change: Monitor for changes in Sysmon configuration related to system boot processes or system integrity checks.