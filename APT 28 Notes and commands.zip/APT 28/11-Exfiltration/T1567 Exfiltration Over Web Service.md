

Windows Event Viewer:

- Event ID 5156 (Windows Server 2008 and later): The Windows Filtering Platform has permitted a connection, which could indicate an adversary exfiltrating data using a web service.
    
- Event ID 4663 (Windows Server 2008 and later): An attempt was made to access an object, which could indicate an adversary accessing sensitive files to prepare for data exfiltration over a web service.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections to web services, especially those originating from unexpected or unauthorized sources, which could indicate an adversary attempting to exfiltrate data using a web service.
    
- Event ID 10 - Process accessed: Monitor for processes accessing web service-related processes or services, such as web browsers, API clients, or cloud storage applications, especially those with unusual command-line arguments or suspicious behaviors.