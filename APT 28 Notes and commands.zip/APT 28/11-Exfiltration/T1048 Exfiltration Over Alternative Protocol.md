
Alternate protocols include FTP, SMTP, HTTP/S, DNS, SMB, or any other network protocol not being used as the main command and control channel. Adversaries may also opt to encrypt and/or obfuscate these alternate channels.


Windows Event Viewer:

- Event ID 5156 (Windows Server 2008 and later): The Windows Filtering Platform has permitted a connection, which could indicate an adversary exfiltrating data using an alternative protocol.
    
- Event ID 5155 (Windows Server 2008 and later): The Windows Filtering Platform has blocked a connection, which could indicate an adversary attempting to exfiltrate data using a non-standard protocol.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections using non-standard or unusual protocols, especially those originating from unexpected or unauthorized sources, which could indicate an adversary attempting to exfiltrate data using an alternative protocol.
    
- Event ID 10 - Process accessed: Monitor for processes accessing network-related processes or services, such as communication software or utilities, especially those with unusual command-line arguments or suspicious behaviors, which could indicate an adversary attempting to use alternative protocols for data exfiltration.