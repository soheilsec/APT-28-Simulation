


Windows Event Viewer:

- Event ID 4624 (Windows Server 2008 and later): An account was successfully logged on, which could indicate an adversary using valid credentials to access a system or service.
    
- Event ID 4625 (Windows Server 2008 and later): An account failed to log on, which could indicate an adversary attempting to use valid credentials but entering incorrect passwords.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to logon attempts or credential dumping tools, such as net.exe, cmd.exe, or powershell.exe.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes related to logon attempts or credential manipulation.