

Additional Email Delegate Permissions T1098.002
 `Add-MailboxPermission` 
 BEC (Business Email Compromise) 

Windows Event Viewer:

- Event ID 4738 (Windows Server 2008 and later): A user account was changed, which could indicate an adversary modifying an existing account.
    
- Event ID 4732 (Windows Server 2008 and later): A member was added to a security-enabled global group, which could indicate an adversary adding a user to a privileged group for lateral movement or privilege escalation.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to account manipulation, such as net.exe, net1.exe, or powershell.exe.
    
- Event ID 2 - File creation time change: Monitor for changes in file creation timestamps related to sensitive system files or account configuration files.
    
- Event ID 6 - Driver loaded: Monitor for the loading of drivers related to account manipulation or credential theft.