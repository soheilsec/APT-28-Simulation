

Component Object Model Hijacking T1546.015



Windows Event Viewer:

- Event ID 4657 (Windows Server 2008 and later): A registry value was modified, which could indicate the modification of COM-related registry keys for hijacking.
    
- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a process related to COM hijacking attempts.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to COM hijacking or suspicious executables with unusual command-line arguments.
    
- Event ID 13 - Registry operation: Monitor for modifications to registry keys related to COM objects, such as HKEY_LOCAL_MACHINE\Software\Classes\CLSID and HKEY_LOCAL_MACHINE\Software\Classes\TypeLib.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to COM hijacking, such as malicious DLLs or executables.