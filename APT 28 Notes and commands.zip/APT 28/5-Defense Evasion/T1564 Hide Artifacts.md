

Hidden Files and Directories T1564.001

```cmd
attrib.exe +h #{file_to_modify}
```

```cmd
del /A:H #{file_to_modify} >nul 2>&1
```

disable show hidden option folder with registry:

```cmd
reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced /v ShowSuperHidden /t REG_DWORD /d 0 /f
reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced /v Hidden /t REG_DWORD /d 0 /f
```

```cmd
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ShowSuperHidden /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v Hidden /f >nul 2>&1
```

Windows Event Viewer:

- Event ID 4656 (Windows Server 2008 and later): A handle to an object was requested, which could indicate access or manipulation of hidden files or directories.
    
- Event ID 4663 (Windows Server 2008 and later): An attempt was made to access an object, which could indicate an adversary attempting to interact with hidden files or directories.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes with unusual command-line arguments or those executing from hidden directories.
    
- Event ID 2 - File creation time change: Monitor for changes in file creation timestamps related to hidden files or directories.
    
- Event ID 5 - File modified: Monitor for modifications to hidden files or directories, especially those related to critical system components or sensitive data.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to hidden files or directories, especially those that are not part of standard system or application operations.


Hidden Window T1564.003
Adversaries may use hidden windows to conceal malicious activity from the plain sight of users. In some cases, windows that would typically be displayed when an application carries out an operation can be hidden. This may be utilized by system administrators to avoid disrupting user work environments when carrying out administrative tasks.

Adversaries may abuse these functionalities to hide otherwise visible windows from users so as not to alert the user to adversary activity on the system.[[1]](https://blog.malwarebytes.com/threat-analysis/2017/01/new-mac-backdoor-using-antiquated-code/)

On macOS, the configurations for how applications run are listed in property list (plist) files. One of the tags in these files can be `apple.awt.UIElement`, which allows for Java applications to prevent the application's icon from appearing in the Dock. A common use for this is when applications run in the system tray, but don't also want to show up in the Dock.

Similarly, on Windows there are a variety of features in scripting languages, such as [PowerShell](https://attack.mitre.org/techniques/T1059/001), Jscript, and [Visual Basic](https://attack.mitre.org/techniques/T1059/005) to make windows hidden. One example of this is `powershell.exe -WindowStyle Hidden`.[[2]](https://docs.microsoft.com/en-us/powershell/module/Microsoft.PowerShell.Core/About/about_PowerShell_exe?view=powershell-5.1)

In addition, Windows supports the `CreateDesktop()` API that can create a hidden desktop window with its own corresponding `explorer.exe` process.[[3]](https://www.malwaretech.com/2015/09/hidden-vnc-for-beginners.html)[[4]](https://securityintelligence.com/anatomy-of-an-hvnc-attack/) All applications running on the hidden desktop window, such as a hidden VNC (hVNC) session,[[3]](https://www.malwaretech.com/2015/09/hidden-vnc-for-beginners.html) will be invisible to other desktops windows.

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to applications or services that could create hidden windows or manipulate user interface elements.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes related to windows management or user interface manipulation, especially those with unusual command-line arguments or suspicious behaviors.