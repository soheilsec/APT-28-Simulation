
Token Impersonation / Theft T1134.001


Windows Event Viewer:

- Event ID 4624: A successful logon occurred, which could indicate an adversary using a stolen token to impersonate a legitimate user.
    
- Event ID 4672: Special privileges were assigned to a new logon, which could indicate an adversary gaining elevated access by impersonating a privileged user or process.
    

Sysmon:

- Event ID 1: A process was created, which could indicate the launch of a process related to token impersonation.
    
- Event ID 10: A process accessed another process, which could indicate an adversary manipulating or stealing tokens from a running process.
    
- Event ID 13: A registry operation occurred, which could indicate modifications to registry keys related to token impersonation.