

Rundll32 T1218.011


Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a signed system binary being used as a proxy for malicious activity.
    
- Event ID 4688 with Command Line arguments (Windows Server 2008 and later): Look for unusual or suspicious command-line arguments associated with signed system binaries that could indicate proxy execution of malicious content.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of signed system binaries with unusual command-line arguments or those executed from unusual locations.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to signed system binaries being used in unexpected ways or for suspicious purposes.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes related to signed system binaries, especially those with unusual command-line arguments or suspicious behaviors.