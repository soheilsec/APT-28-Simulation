
Encrypted/Encoded File T1027.013




Windows Event Viewer:

- Event ID 4656 (Windows Server 2008 and later): A handle to an object was requested, which could indicate access or manipulation of encrypted or encoded files.
    
- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a process related to encrypting or decoding files.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to encryption tools, encoding utilities, or suspicious executables with unusual command-line arguments.
    
- Event ID 2 - File creation time change: Monitor for changes in file creation timestamps related to encrypted or encoded files.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to encrypted or encoded files or suspicious tools associated with this technique.