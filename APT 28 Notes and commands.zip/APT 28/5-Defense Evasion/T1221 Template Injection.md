


Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a process related to template injection, such as code execution via template injection.
    
- Event ID 4656 (Windows Server 2008 and later): A handle to an object was requested, which could indicate access or manipulation of files containing templates vulnerable to injection attacks.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to applications or services that use templates, especially those with unusual command-line arguments or running in a suspicious context.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to templates or applications that use templates, which could indicate an adversary attempting to exploit template injection vulnerabilities.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes related to applications that use templates, especially those with unusual command-line arguments or suspicious behaviors.