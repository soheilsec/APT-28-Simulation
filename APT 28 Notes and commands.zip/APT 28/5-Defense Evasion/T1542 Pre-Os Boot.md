
bootkit T1542.003

 