


Windows Event Viewer:

- Event ID 4697 (Windows Server 2008 and later): A service was installed in the system, which could indicate the installation of a malicious rootkit service.
    
- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a process related to a rootkit.
    
- Event ID 6281 (Windows Server 2008 and later): Code Integrity checks were performed on a file, which could indicate attempts to load an unsigned or potentially malicious driver.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to rootkits or suspicious executables with unusual command-line arguments.
    
- Event ID 6 - Driver loaded: Monitor for the loading of drivers related to rootkits or suspicious kernel modules.
    
- Event ID 13 - Registry operation: Monitor for modifications to registry keys related to system startup or critical system components, such as HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services.