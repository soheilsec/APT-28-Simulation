

Renaming abusable system utilities to evade security monitoring is also a form of [Masquerading](https://attack.mitre.org/techniques/T1036).[[1]](https://lolbas-project.github.io/)

Match Legitimate Name or Location T1036.005

svchost.exe

Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a process related to masquerading attempts, such as renaming or modifying system utilities.
- Event ID 4648 (Windows Server 2008 and later): A logon was attempted using explicit credentials, which could indicate an adversary trying to masquerade as another user.

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to masquerading, such as command shells or renamed system utilities.
    
- Event ID 3 - Network connections: Monitor for network connections made by processes associated with masquerading attempts, especially those connecting to internal systems.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes related to masquerading, such as command shells or security-related processes.



===

Windows Event Viewer:

- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a process with a name or location designed to mimic legitimate applications or system utilities.
    
- Event ID 4663 (Windows Server 2008 and later): An attempt was made to access an object, which could indicate an adversary attempting to interact with files or directories using names or locations that mimic legitimate resources.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes with names or command-line arguments that mimic legitimate applications or system utilities.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions in locations that mimic legitimate application or system directories, or using names that resemble legitimate files.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes or files related to the legitimate applications they are attempting to mimic.