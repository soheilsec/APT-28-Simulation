
```cmd
certutil -encode c:\windows\system32\calc.exe calcencode.txt
```

```cmd
certutil -decode calcencode.txt calc.exe
```


Windows Event Viewer:

- Event ID 4656 (Windows Server 2008 and later): A handle to an object was requested, which could indicate access or manipulation of obfuscated or encoded files.
    
- Event ID 4688 (Windows Server 2008 and later): A new process has been created, which could indicate the launch of a process related to deobfuscation or decoding of files.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to deobfuscation tools, encoding utilities, or suspicious executables with unusual command-line arguments.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to obfuscated, encoded, or decoded files or suspicious tools associated with this technique.
    
- Event ID 13 - Registry operation: Monitor for modifications to registry keys related to deobfuscation tools or encoding utilities.