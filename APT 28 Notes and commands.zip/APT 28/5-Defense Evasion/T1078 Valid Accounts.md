

Cloud Accounts [T1078.004 - Enterprise](https://attack.mitre.org/techniques/T1078/004)



Windows Event Viewer:

- Event ID 4624 (Windows Server 2008 and later): An account was successfully logged on, which could indicate an adversary accessing cloud accounts using stolen credentials.
    
- Event ID 4648 (Windows Server 2008 and later): A logon was attempted using explicit credentials, which could indicate an adversary trying to access cloud accounts using valid credentials.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to cloud applications or services.
    
- Event ID 3 - Network connections: Monitor for network connections made to known cloud service providers or related domains.
    
- Event ID 10 - Process accessed: Monitor for processes accessing other processes related to cloud applications or services.