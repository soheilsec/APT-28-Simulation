

Remote Email collection T1114.002


Windows Event Viewer:

- Event ID 4648 (Windows Server 2008 and later): A logon attempt was made using explicit credentials, which could indicate an adversary using captured credentials obtained through remote email collection.
    
- Event ID 7045 (Windows Server 2008 and later): A new service was installed on the system, which could indicate an adversary installing a malicious service to facilitate remote email collection.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections made to email servers or services, especially those originating from unexpected or unauthorized sources, which could indicate an adversary collecting emails remotely.
    
- Event ID 10 - Process accessed: Monitor for processes accessing email-related processes or services, such as Outlook, Thunderbird, or webmail clients, especially those with unusual command-line arguments or suspicious behaviors.

