

Windows Event Viewer:

- Event ID 5140 (Windows Server 2008 and later): A network share object was accessed, which could indicate an adversary attempting to access data on a network shared drive.
    
- Event ID 4663 (Windows Server 2008 and later): An attempt was made to access an object, which could indicate an adversary attempting to access sensitive files on a network shared drive.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections made to network shared drives, especially those originating from unexpected or unauthorized sources.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to network shared drive activities, especially those that are not part of standard system or application operations.
    
- Event ID 10 - Process accessed: Monitor for processes accessing network shared drive-related processes or services, such as smb.exe, net.exe, or PowerShell commands related to network shares, especially those with unusual command-line arguments or suspicious behaviors.