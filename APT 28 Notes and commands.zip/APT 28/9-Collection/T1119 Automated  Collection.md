
```cmd
mkdir %temp%\collection1 >nul 2>&1
dir c: /b /s .docx | findstr /e .docx
for /R c:\ %f in (*.docx) do copy /Y %f %temp%\collection1
```


Windows Event Viewer:

- Event ID 4698 (Windows Server 2008 and later): A scheduled task was created, which could indicate an adversary setting up an automated data collection mechanism.
    
- Event ID 4104 (Windows Server 2008 and later): A script was executed, which could indicate an adversary using scripts for automated data collection.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to scripting engines or task scheduling tools, such as powershell.exe, wscript.exe, cscript.exe, or schtasks.exe, especially those with unusual command-line arguments or suspicious behaviors.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to automated data collection scripts or scheduled tasks, especially those that are not part of standard system or application operations.
    
- Event ID 10 - Process accessed: Monitor for processes accessing script execution or task scheduling-related processes or services, such as script hosts, task scheduler service, or PowerShell automation components, especially those with unusual command-line arguments or suspicious behaviors.