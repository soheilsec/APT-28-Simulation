
```powershell
$startingDirectory = "C:\Users"
$outputZip = "c:\"
$fileExtensionsString = ".doc, .docx, .txt" 
$fileExtensions = $fileExtensionsString -split ", "

New-Item -Type Directory $outputZip -ErrorAction Ignore -Force | Out-Null

Function Search-Files {
  param (
    [string]$directory
  )
  $files = Get-ChildItem -Path $directory -File -Recurse | Where-Object {
    $fileExtensions -contains $_.Extension.ToLower()
  }
  return $files
}

$foundFiles = Search-Files -directory $startingDirectory
if ($foundFiles.Count -gt 0) {
  $foundFilePaths = $foundFiles.FullName
  Compress-Archive -Path $foundFilePaths -DestinationPath "$outputZip\data.zip"

  Write-Host "Zip file created: $outputZip\data.zip"
  } else {
      Write-Host "No files found with the specified extensions."
  }
```

Windows Event Viewer:

- Event ID 4656 (Windows Server 2008 and later): A handle to an object was requested, which could indicate an adversary attempting to access sensitive files for data collection.
    
- Event ID 4663 (Windows Server 2008 and later): An attempt was made to access an object, which could indicate an adversary attempting to access sensitive files for data collection.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to data exfiltration or archiving tools, such as compression utilities, FTP clients, or known adversary tools, especially those with unusual command-line arguments.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to data collection activities, especially those that are not part of standard system or application operations.
    
- Event ID 10 - Process accessed: Monitor for processes accessing file-related processes or services, such as explorer.exe, cmd.exe, or PowerShell, especially those with unusual command-line arguments or suspicious behaviors.