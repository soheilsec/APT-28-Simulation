

sharepoint T1213.002


Windows Event Viewer:
- Event ID 5140 (Windows Server 2008 and later): A network share object was accessed, which could indicate an adversary attempting to access sensitive files stored in SharePoint libraries.
- Event ID 7045 (Windows Server 2008 and later): A new service was installed on the system, which could indicate an adversary installing a malicious service to facilitate SharePoint exploitation.

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections made to SharePoint servers or services, especially those originating from unexpected or unauthorized sources, which could indicate an adversary attempting to access or manipulate SharePoint resources.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to SharePoint data, especially those that are not part of standard system or application operations.
    
- Event ID 10 - Process accessed: Monitor for processes accessing SharePoint-related processes or services, such as Microsoft.SharePoint.exe, SharePoint PowerShell modules, or SharePoint APIs, especially those with unusual command-line arguments or suspicious behaviors.