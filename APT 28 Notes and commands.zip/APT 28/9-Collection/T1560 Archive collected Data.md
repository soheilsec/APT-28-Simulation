
Archive Via Utility T1560.001


Windows Event Viewer:

- Event ID 4656 (Windows Server 2008 and later): A handle to an object was requested, which could indicate an adversary attempting to access files for archiving purposes.
    
- Event ID 4663 (Windows Server 2008 and later): An attempt was made to access an object, which could indicate an adversary attempting to access sensitive files for archiving purposes.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to archiving or compression utilities, such as winrar.exe, 7z.exe, or tar.exe, especially those with unusual command-line arguments.
    
- Event ID 7 - File system operations: Monitor for file creations or modifications related to compressed or encrypted archives, especially those that are not part of standard system or application operations.
    
- Event ID 10 - Process accessed: Monitor for processes accessing archiving or compression-related processes or services, such as archive tools, compression libraries, or encryption modules, especially those with unusual command-line arguments or suspicious behaviors.