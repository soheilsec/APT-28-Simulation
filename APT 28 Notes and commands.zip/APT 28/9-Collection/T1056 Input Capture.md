
Keylogging T1056.001


Windows Event Viewer:

- Event ID 4648 (Windows Server 2008 and later): A logon attempt was made using explicit credentials, which could indicate an adversary using captured credentials obtained through keylogging.
    
- Event ID 7045 (Windows Server 2008 and later): A new service was installed on the system, which could indicate an adversary installing a malicious service to capture user input.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to keylogging tools, such as known keylogger applications or suspicious processes with keyboard or input-related names, especially those with unusual command-line arguments.
    
- Event ID 10 - Process accessed: Monitor for processes accessing keyboard or user input-related processes or services, such as winlogon.exe, explorer.exe, or user32.dll, especially those with unusual command-line arguments or suspicious behaviors.