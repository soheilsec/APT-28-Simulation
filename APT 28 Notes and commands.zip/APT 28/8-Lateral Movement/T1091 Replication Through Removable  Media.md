

Windows Event Viewer:

- Event ID 2003 (Windows Vista and later): The system detected a device insertion or removal, which could indicate an adversary attempting to use removable media for replication purposes.
    
- Event ID 2147 (Windows Server 2008 and later): A network share object was added, removed, or changed, which could indicate an adversary creating shares to access removable media for replication.
    

Sysmon:

- Event ID 1 - Process creation: Monitor for the creation of processes related to file management or data transfer, especially those involving removable media or unusual command-line arguments.
    
- Event ID 7 - File system operations: Monitor for file creations, modifications, or deletions related to removable media, especially those that are not part of standard system or application operations.
    
- Event ID 10 - Process accessed: Monitor for processes accessing file management processes or services, such as explorer.exe, cmd.exe, or PowerShell, especially those with unusual command-line arguments or suspicious behaviors.